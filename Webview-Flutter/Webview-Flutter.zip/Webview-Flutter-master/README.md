# Webview-Flutter
A Flutter plugin that provides a WebView widget on Android and iOS.

# Demo
![git_img](https://user-images.githubusercontent.com/65654295/82568623-b9a4a500-9b9c-11ea-8090-6bdd037881c5.gif)

# Getting Started 

